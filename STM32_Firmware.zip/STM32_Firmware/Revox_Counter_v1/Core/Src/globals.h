/*
 * globals.h
 *
 *  Created on: Sep 25, 2024
 *      Author: Tisho
 */

#ifndef SRC_GLOBALS_H_
#define SRC_GLOBALS_H_

//Flash addres for constant saving
#define EEPROM_ADR 0x08020000	//Starting addres of the Flash used as EEPROM storage



//Display
#define DISPLAY_DIGITS 5		//LED Display digits count
#define maxDispIdx 8			//Max count of display positions (L tape, Time, Speed.....)

extern int vDispNewDataFlgs;	//flags for new data to display available
extern int vDispIdx;			//flags for display Index (what is displayed at the moment)
extern int vDefDisp;			//Default display Index (Time, L-Tape or Counter) - at startup


//Timer
extern int vSysFlgs;			//flag set by the hardware Timer3 interrupt  (1ms)


//********************************* Display *****************************************
#define Disp_LT	1			//Tape length
#define Disp_TM	1<<1		//Tape time
#define Disp_CNT	1<<2	//Tape counter  (RAW data)
#define DispSPD	1<<3		//Tape speed
#define DispTpTh	1<<4	//Tape thickness
#define DispLRD	1<<5		//Left reel diameter
#define DispRRD	1<<6		//Right reel diameter

extern char ForceDisp;

extern char vDispBRT;		//Display brightness

//********************************** Reel and Tape Calculations **********************

//***********************************************************
#define ReelN_Ref 8   			//Number of reflectors on the motor hub

#define ReelMax 27    //max size of the Reel in cm (full with tape)
#define ReelMin 4    //min size of the Reel in cm (empty)

#define DefTypTapeThick 35
#define DefMaxTapeThick 120

#define DefCallDur 20     //sets how many full reel revolutions are needed for reliable Tape Thikness estimation
#define DefRellDCallRot 16 //DefCallDur- needed Revolutions for Diameter estimation

#define VallidTpS 2         //How many consequent tape speed measurements are needed to say that the tape speed is "Valid"
                            //Needed when starting to fast forward (when speed is 9.5) is falsely detecting speed 19


//extern char vTapeSpeed;			//Tape speed (0 -> 9.5cm/s ; 1 -> 19,5cm/s)

extern char FlgNewDataRR, FlgNewDataLR;
extern char FlgNewFullR_RR, FlgNewFullR_LR;
extern unsigned int CntTmRR, CntTmLR;		 	//Time between each ref.
extern unsigned int CntTmRR_Full, CntTmLR_Full; //Time for the full reel rotation

extern int CntRR;          //counter the right reel ref. marks
extern int CntLR;          //counter the left reel ref. marks

extern char FlgCalcCoeff;       //Flag for Coefitiens calculation
extern char FlgCountRST;        //Flag for counter reset (use the old calibration data)

extern char FlgTapeMode;       //Flag indicating the tape recorder mode (play, stop)

extern char FlgTapeDir;        //Flag indicating in which direction the tape is moving
extern float TapeSpeed;       //Calculated Tape Speed
extern float TapeThick;           //Calculated Tape Thickness

extern float LTape;               //Elapsed Tape length
extern char FlgLTapeUpd;       //flag new LTape Data available
extern char FlgTapeCntUpd;     //flag new Tape counter available (CntRR or CntLR)

extern float DReel_Cur_R;           //calculated Diameter of the reel (every length calculation) Right -> needed if we want to "0" the counter
extern float DReel_Cur_L;           //calculated Diameter of the reel (every length calculation) Left -> needed if we want to "0" the counter

#define VallidTpS 2         //How many consequent tape speed measurements are needed to say that the tape speed is "Valid"
                            //Needed when starting to fast forward (when speed is 9.5) is falsely detecting speed 19


#endif /* SRC_GLOBALS_H_ */
