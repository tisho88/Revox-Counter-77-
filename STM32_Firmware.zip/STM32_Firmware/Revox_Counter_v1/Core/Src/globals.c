/*
 * globals.c
 *
 *  Created on: Sep 25, 2024
 *      Author: Tisho
 */

#include "globals.h"

//Display





//Timer
int vSysFlgs;			//flag set by the hardware Timer3 interrupt  (1ms)

//********************************* Display *****************************************
/*
 * 1 - L tape
 * 2 - Time
 * 3 - Counter
 * 4 - Speed
 * 5 - Tape Thikness
 * 6 - Left reel diameter
 * 7 - Right reel diameter
 *
 * it is valid for "vDispNewDataFlgs" - not fully true (it was the initial idea, in reality much less of them are used)
 */
int vDispNewDataFlgs;	//flags for new data to display available
int vDispIdx;			//flags for display Index (what is displayed at the moment)
int vDefDisp;			//Default display Index (Time, L-Tape or Counter) - at startup

char ForceDisp;

char vDispBRT;			//Display brightness

//********************************** Reel and Tape Calculations **********************


//char vTapeSpeed;			//Tape speed (0 -> 9.5cm/s ; 1 -> 19,5cm/s)

char FlgNewDataRR, FlgNewDataLR;
char FlgNewFullR_RR, FlgNewFullR_LR;
unsigned int CntTmRR, CntTmLR;			 //Time between each ref.
unsigned int CntTmRR_Full, CntTmLR_Full; //Time for the full reel rotation

int CntRR;          //counter the right reel ref. marks
int CntLR;          //counter the left reel ref. marks

char FlgCalcCoeff;       //Flag for Coefitiens calculation
char FlgCountRST;        //Flag for counter reset (use the old calibration data)

char FlgTapeMode;       //Flag indicating the tape recorder mode (play, stop)

char FlgTapeDir;        //Flag indicating in which direction the tape is moving
float TapeSpeed;       //Calculated Tape Speed
float TapeThick;           //Calculated Tape Thickness

float LTape;               //Elapsed Tape length
char FlgLTapeUpd;       //flag new LTape Data available
char FlgTapeCntUpd;     //flag new Tape counter available (CntRR or CntLR)

float DReel_Cur_R;           //calculated Diameter of the reel (every length calculation) Right -> needed if we want to "0" the counter
float DReel_Cur_L;           //calculated Diameter of the reel (every length calculation) Left -> needed if we want to "0" the counter
