/*
 * max72xx.c
 *
 * Minimalistic library for the MAX7219 and MAX7221 7 segment LED drivers
 *
 * See: https://stm32world.com/wiki/STM32_MAX7219/MAX7221
 *
 *
 */

/*
 *
 *  Modified on: Sep 26, 2024
 *      By: Tihomir Angelov
 */

#include <math.h>
#include <string.h>
#include <stdint.h>
#include <stdio.h>
#include "main.h"
//#include "stm32f4xx_hal.h"
#include "max72xx.h"
#include "globals.h"
# include "sys_stm32f401.h"


MAX72XX_HandleTypeDef max72xx;

/*
 *
 * Private Variables
 *
 */

char CntSplScr = 0;			//Counter for the spash screen


const uint8_t max72xx_font[] = {
        0b01111110, // 0
        0b00110000, // 1
        0b01101101, // 2
        0b01111001, // 3
        0b00110011, // 4
        0b01011011, // 5
        0b01011111, // 6
        0b01110000, // 7
        0b01111111, // 8
        0b01111011, // 9
        0b00000001, // -
        0b01001111, // E
        0b00110111, // H
        0b00001110, // L
        0b01100111, // P
        0x00000000, // blank
};

const uint8_t SevenSegmentASCII[96] = {
	0b00000000, /* (space) */
	0b10000110, /* ! */
	0b00100010, /* " */
	0b01111110, /* # */
	0b01101101, /* $ */
	0b11010010, /* % */
	0b01000110, /* & */
	0b00100000, /* ' */
	0b00101001, /* ( */
	0b00001011, /* ) */
	0b00100001, /* * */
	0b01110000, /* + */
	0b00010000, /* , */
	0b00000001, /* - */
	0b10000000, /* . */
	0b01010010, /* / */
	0b01111110, // 0			//Valid
	0b00110000, // 1
	0b01101101, // 2
	0b01111001, // 3
	0b00110011, // 4
	0b01011011, // 5
	0b01011111, // 6
	0b01110000, // 7
	0b01111111, // 8
	0b01111011, // 9			//Valid
	0b00001001, /* : */
	0b00001101, /* ; */
	0b01100001, /* < */
	0b01001000, /* = */
	0b01000011, /* > */
	0b11010011, /* ? */
	0b01011111, /* @ */
	0b01110111, /* A */
	0b00011111, /* B b*/
	0b01001110, /* C */
	0b00111101, /* D d*/
	0b01001111, /* E */
	0b01000111, /* F */
	0b01011111, /* G */
	0b00010111, /* H */
	0b00110000, /* I */
	0b00000000, /* J */
	0b00000000, /* K */
	0b00001110, /* L */
	0b00000000, /* M */
	0b00010101, /* N */
	0b01111110, /* O */
	0b01100111, /* P */
	0b00000000, /* Q */
	0b00000101, /* R r*/
	0b01011011, /* S */
	0b00001111, /* T t*/
	0b00111110, /* U */
	0b00011100, /* V */
	0b00000000, /* W */
	0b00000000, /* X */
	0b00000000, /* Y */
	0b00000000, /* Z */
	0b00111001, /* [ */
	0b01100100, /* \ */
	0b00001111, /* ] */
	0b00100011, /* ^ */
	0b00001000, /* _ */
	0b00000010, /* ` */
	0b01011111, /* a */			//From here have to be reworked some day
	0b01111100, /* b */
	0b01011000, /* c */
	0b01011110, /* d */
	0b01111011, /* e */
	0b01110001, /* f */
	0b01101111, /* g */
	0b01110100, /* h */
	0b00010000, /* i */
	0b00001100, /* j */
	0b01110101, /* k */
	0b00110000, /* l */
	0b00010100, /* m */
	0b01010100, /* n */
	0b01011100, /* o */
	0b01110011, /* p */
	0b01100111, /* q */
	0b01010000, /* r */
	0b01101101, /* s */
	0b01111000, /* t */
	0b00011100, /* u */
	0b00011100, /* v */
	0b00010100, /* w */
	0b01110110, /* x */
	0b01101110, /* y */
	0b01011011, /* z */
	0b01000110, /* { */
	0b00110000, /* | */
	0b01110000, /* } */
	0b00000001, /* ~ */
	0b00000000, /* (del) */
};

/*
 *
 * Private Internal Functions
 *
 */

void max72xx_cs_enable(MAX72XX_HandleTypeDef *max72xx) {
    HAL_GPIO_WritePin(max72xx->cs_port, max72xx->cs_pin, GPIO_PIN_RESET);
}

void max72xx_cs_disable(MAX72XX_HandleTypeDef *max72xx) {
    HAL_GPIO_WritePin(max72xx->cs_port, max72xx->cs_pin, GPIO_PIN_SET);
}

MAX72XX_result_t max72xx_transmit(MAX72XX_HandleTypeDef *max72xx, uint8_t address, uint8_t value) {
    MAX72XX_result_t result = MAX72XX_Ok;

    uint8_t data[2] = { address, value };

    max72xx_cs_enable(max72xx);
    if (HAL_SPI_Transmit(max72xx->spiHandle, (uint8_t*) &data, 2, HAL_MAX_DELAY) != HAL_OK)
        result = MAX72XX_Err;
    max72xx_cs_disable(max72xx);

    return result;
}

/*
 *
 * Public Functions
 *
 */

/**
 * @brief Initialize the MAX72XX library/driver.
 * @param Pointer to a max72xx handle
 * @param hspi pointer to a SPI_HandleTypeDef structure that contains
 *               the configuration information for SPI module.
 * @param Chip select port
 * @param Chip select pin
 * @retval MAX72XX Status
 */
MAX72XX_result_t max72xx_init(MAX72XX_HandleTypeDef *max72xx, SPI_HandleTypeDef *hspi, GPIO_TypeDef *cs_port, uint16_t cs_pin) {
    MAX72XX_result_t result = MAX72XX_Ok;

    max72xx->spiHandle = hspi;
    max72xx->cs_port = cs_port;
    max72xx->cs_pin = cs_pin;

    return result;
}

MAX72XX_result_t max72xx_shutdown(MAX72XX_HandleTypeDef *max72xx) {
    MAX72XX_result_t result = MAX72XX_Ok;
    if (max72xx_transmit(max72xx, MAX72XX_SHUTDOWN, 0) != MAX72XX_Ok) {
        return MAX72XX_Err;
    }
    max72xx->awake = 0;
    return result;
}

MAX72XX_result_t max72xx_wakeup(MAX72XX_HandleTypeDef *max72xx) {
    MAX72XX_result_t result = MAX72XX_Ok;

    max72xx_transmit(max72xx, MAX72XX_DISPLAY_TEST, 0);			//Important! -> disable the display tet mode

    if (max72xx_transmit(max72xx, MAX72XX_SHUTDOWN, 1) != MAX72XX_Ok) {
        return MAX72XX_Err;
    }
    max72xx->awake = 1;
    return result;
}

MAX72XX_result_t max72xx_digits(MAX72XX_HandleTypeDef *max72xx, uint8_t digits) {
    MAX72XX_result_t result = MAX72XX_Ok;
    if (max72xx_transmit(max72xx, MAX72XX_SCAN_LIMIT, digits - 1) != MAX72XX_Ok) {
        return MAX72XX_Err;
    }
    max72xx->digits = digits;
    return result;
}

MAX72XX_result_t max72xx_intensity(MAX72XX_HandleTypeDef *max72xx, uint8_t intensity) {
    MAX72XX_result_t result = MAX72XX_Ok;
    if (max72xx_transmit(max72xx, MAX72XX_INTENSITY, intensity) != MAX72XX_Ok) {
        return MAX72XX_Err;
    }
    max72xx->intensity = intensity;
    return result;
}

MAX72XX_result_t max72xx_decode(MAX72XX_HandleTypeDef *max72xx, uint8_t decode) {
    MAX72XX_result_t result = MAX72XX_Ok;
    if (max72xx_transmit(max72xx, MAX72XX_DECODE_MODE, decode) != MAX72XX_Ok) {
        return MAX72XX_Err;
    }
    max72xx->decode = decode;
    return result;
}

MAX72XX_result_t max72xx_set_digit(MAX72XX_HandleTypeDef *max72xx, uint8_t digit, uint8_t value) {
    MAX72XX_result_t result = MAX72XX_Ok;

 //Work around (flipped the cathodes on the PCB)
    if (digit == 5)
    	digit = 1;
    else if(digit == 4)
    	digit = 2;
    else if(digit == 2)
        digit = 4;
    else if(digit == 1)
        digit = 5;


    if (max72xx_transmit(max72xx, digit, value) != MAX72XX_Ok) {
        result = MAX72XX_Err;
    }

    return result;

}


MAX72XX_result_t max72xx_display_number(MAX72XX_HandleTypeDef *max72xx, uint32_t number) {
    MAX72XX_result_t result = MAX72XX_Ok;

    uint8_t digit_count = log10(number) + 1;
    if(digit_count == 0)
    	digit_count++;

    for (int i = max72xx->digits; i > 0; --i) {
        uint8_t digit_decode = 0x01 & (max72xx->decode >> (i - 1));
        if (i <= digit_count) {
            uint32_t digit = ((uint32_t) (number / pow(10, i - 1))) % 10;
            if (!digit_decode)
            		digit = max72xx_font[digit];

            max72xx_set_digit(max72xx, i, (uint8_t) digit);
        } else {
            if (digit_decode) {
                max72xx_set_digit(max72xx, i, 0x0f);
            } else {
                max72xx_set_digit(max72xx, i, 0x00);
            }
        }
    }

    return result;
}


MAX72XX_result_t max72xx_display_Txt_Num(MAX72XX_HandleTypeDef *max72xx, char *Txt, uint32_t number) {
    MAX72XX_result_t result = MAX72XX_Ok;

    uint8_t digit_count = log10(number) + 1;

    for (int i = max72xx->digits; i > 0; --i) {
        uint8_t digit_decode = 0x01 & (max72xx->decode >> (i - 1));
        if (i <= digit_count) {
            uint32_t digit = ((uint32_t) (number / pow(10, i - 1))) % 10;
            if (!digit_decode) digit = max72xx_font[digit];
            max72xx_set_digit(max72xx, i, (uint8_t) digit);
        } else {
            if (digit_decode) {
                max72xx_set_digit(max72xx, i, 0x0f);
            } else {
                max72xx_set_digit(max72xx, i, 0x00);
            }
        }
    }

    return result;
}

MAX72XX_result_t max72xx_display_Txt(MAX72XX_HandleTypeDef *max72xx, char *Txt) {
    MAX72XX_result_t result = MAX72XX_Ok;

    uint8_t digit_count = strlen(Txt);
    uint8_t digit_count_act = digit_count;
    uint8_t IndIDX;

    //Check how much actual characters (remove the decimal points)
    for (int i = 0; i <= digit_count; i++)
        {
        	 if((Txt[i]) == 46)
        		 digit_count_act --;
        }
        IndIDX =  max72xx->digits;


        for (int i = 0; i <= max72xx->digits; i++)
        	{
        	if((Txt[i]) != 46 )		//is the current symbol in the string "."
        		{
        		uint8_t digit = Txt[i];
        		digit = SevenSegmentASCII[digit-32];
        		if((Txt[i+1]) == 46 )		//is the next symbol in the string "."
        			digit = digit + 0x80;
        		if(IndIDX>0)
        			{
        			max72xx_set_digit(max72xx, IndIDX, (uint8_t) digit);
        			IndIDX--;
        			 }
        		}
        	}

    return result;
}


//Dots - where to put the time points (if needed, if not just send "0")
MAX72XX_result_t max72xx_display_Time(MAX72XX_HandleTypeDef *max72xx, uint32_t number, char Dots, char Msign) {
    MAX72XX_result_t result = MAX72XX_Ok;

    uint8_t digit_count = log10(number) + 1;
    if(digit_count == 0)
    	digit_count++;

    for (int i = max72xx->digits; i > 0; --i) {
        uint8_t digit_decode = 0x01 & (max72xx->decode >> (i - 1));
        if (i <= digit_count) {
            uint32_t digit = ((uint32_t) (number / pow(10, i - 1))) % 10;
            if (!digit_decode)
            	{
            	if ((i == 5) && Msign)
            		digit = max72xx_font[10];		//"-" sign
            	else if((i == 3) || (i == 5))
            		digit = max72xx_font[digit] + (Dots<<7);
            	else
            		digit = max72xx_font[digit];
            	}

            max72xx_set_digit(max72xx, i, (uint8_t) digit);
        } else {
            if (digit_decode)
            	{
                max72xx_set_digit(max72xx, i, 0x0f);
            	}
            else
            	{
            	if ((i == 5) && Msign)
            		max72xx_set_digit(max72xx, i, 0x01);		//print "-" sign
            	else if(((i == 3) || (i == 5)) && Dots)
            		max72xx_set_digit(max72xx, i, 0xFE);		//print the leading "0" with dots
            	else
            		max72xx_set_digit(max72xx, i, 0x7E);					//print the leading "0" without dots
            	}
        }
    }

    return result;
}



void DispInit(void)
{

	  max72xx_wakeup(&max72xx);                 	// By default it is not running
	  max72xx_digits(&max72xx, DISPLAY_DIGITS); 	// Number of digits to be displayed: 1-8
	  //max72xx_intensity(&max72xx, 0x0F);         	// Intensity MUST be set after the digits
	  max72xx_intensity(&max72xx, vDispBRT);       	// Intensity MUST be set after the digits

	  max72xx_decode(&max72xx, 0b00000000);     	// Disable the built-in number font use our own
	  max72xx_display_number(&max72xx, 0);			//send "0" to empty the display

}

void SplashScreen(char duration, char *Txt)
{
	max72xx_display_Txt(&max72xx, Txt);
	CntSplScr = duration;				// spash screen time = duration*100ms
}

void DispManager(void)
{
	char str[8];

	float LTP_Disp;

	char  CntHour, CntMin, CntSec;

	static uint8_t BlinkCtn;
	static char BlinkState;      //current LED state
	static char Old_BlinkState;      //Old LED state



	if(CntSplScr > 0)			//splash screen not done yet
		{
		if (Verify100msFlg())
			CntSplScr--;		//reduce the Spash screen counter
		}
	else						//splash screen done -> normal display
		{

		//--------------------------------- Blink --------------------------------------
		//if L-tape is selected and Reel diameter is not yet estimated (in other modes no "Blink")
		//if ((FlgCalcCoeff >= DefRellDCallRot) && ((vDispIdx == 1)||(vDispIdx == 2)))
		if (FlgCalcCoeff != 0)                       //Calibration not finished
			 {
			 if(Verify100msFlg())
		      	  {
				 BlinkCtn++;
				 if(BlinkCtn>5)
		         	 {
					 BlinkCtn = 0;
					 if(BlinkState)
					 	 BlinkState = 0;
					 else
						 BlinkState = 1;
		         	 }
		      	  }
		 	 }
		else
			BlinkState = 1;

		switch(vDispIdx)
			{
			case 1:				// L tape
				if((vDispNewDataFlgs & Disp_LT) || (ForceDisp == 1) || (BlinkState != Old_BlinkState))
					{
/*					//alternative way to show the same
					if(LTape>=0)
						max72xx_display_number(&max72xx, (uint32_t)(LTape/10));
					else
						max72xx_display_number(&max72xx, (uint32_t)(100000 + LTape/10));
*/
					Old_BlinkState =  BlinkState;

					LTP_Disp = LTape/100;
					sprintf(str,"%6.1f", LTP_Disp);

					//Do the blinking magic.......

					if ((FlgCalcCoeff >= DefRellDCallRot) && (!BlinkState))
						{
						str[0]= ' ';
						str[1]= ' ';
						str[2]= ' ';
						str[3]= ' ';
						str[4]= ' ';
						str[5]= ' ';
						}
					else if((FlgCalcCoeff != 0) && (!BlinkState))
						str[4]=str[5];		//remove the decimal point



			//		LTP_Disp = LTape/10;
			//		sprintf(str,"%5.0f", LTP_Disp);
					max72xx_display_Txt(&max72xx, str);

					ForceDisp = 0;    //Force display is one time deal
					}

				break;

			case 2:				// Time
				//if((vDispNewDataFlgs & Disp_TM) || (ForceDisp == 1))
				if((vDispNewDataFlgs & Disp_CNT) || (ForceDisp == 1) || (BlinkState != Old_BlinkState))
					{

					Old_BlinkState =  BlinkState;

					int NumData = (LTape/TapeSpeed);

				//	NumData &= (~(1 << 31));		//remove the sign (absolute value)
					if(NumData < 0)
						NumData = NumData*(-1);

				    if(NumData>=3600)
				    	{
				    	CntHour = NumData/3600;
				    	CntMin = (NumData%3600)/60;
				    	CntSec = (NumData%3600)%60;
				    	}
				    else if(NumData>=60)
				    	{
				    	CntHour = 0;
				    	CntMin = NumData/60;
				    	CntSec = NumData%60;
				    	}
				    else
				    	{
				    	CntHour = 0;
				    	CntMin = 0;
				    	CntSec = NumData;
				    	}

				    NumData = CntHour*10000 + CntMin*100 + CntSec;

				    //sprintf(str,"%05d", NumData);

					//Do the blinking magic.......


				    if ((FlgCalcCoeff >= DefRellDCallRot) && (!BlinkState))		//Calibration in the beginning => blink the whole screen
				    	{
				    	max72xx_display_Txt(&max72xx, "     ");			//clear screen
				    	}
				    else
				    	{
				    	if((LTape<0) && (NumData>0))
				    		max72xx_display_Time(&max72xx, NumData, BlinkState, 1);	//dots and "-" sign
				    	else
				    		max72xx_display_Time(&max72xx, NumData, BlinkState, 0);	//dots and no "-" sign
				    	}
				    ForceDisp = 0;    //Force diplay is one time deal
					}
				break;


			case 3:				// Counter
				if((vDispNewDataFlgs & Disp_CNT) || (ForceDisp == 1))
					{
					int CntTot = CntRR-CntLR;

					if(CntTot < 0)
						max72xx_display_number(&max72xx, 100000 + CntTot);
					else
						max72xx_display_number(&max72xx, CntTot);

					ForceDisp = 0;    //Force diplay is one time deal
					}
				break;


			case 4:				//Speed
				/*
				 if((vDispNewDataFlgs & Disp_CNT) || (ForceDisp == 1))
					{
					max72xx_display_number(&max72xx, FlgTapeMode);
					ForceDisp = 0;    //Force diplay is one time deal
					}
				*/



				if((vDispNewDataFlgs & Disp_CNT) || (ForceDisp == 1))
					{
					if(TapeSpeed == 19)
						max72xx_display_Txt(&max72xx, "SP 19");
					else
						max72xx_display_Txt(&max72xx, "SP 9.5");

					ForceDisp = 0;    //Force diplay is one time deal
					}
				break;

			case 5:				//Tape Thickness
				//max72xx_display_Txt(&max72xx, "TP.TH ");
				//if((vDispNewDataFlgs & DispTpTh) || (ForceDisp == 1))
				if((vDispNewDataFlgs & Disp_CNT) || (ForceDisp == 1))
					{

					sprintf(str,"TH%.1f", TapeThick);
					max72xx_display_Txt(&max72xx, str);
					ForceDisp = 0;    //Force diplay is one time deal
					}
				break;

			case 6:				//Left reel diameter
				//if((vDispNewDataFlgs & DispLRD)	|| (ForceDisp == 1))
				if((vDispNewDataFlgs & Disp_CNT) || (ForceDisp == 1))
					{
					//DReel_Cur_L
					sprintf(str,"DL%.2f", DReel_Cur_L);
					max72xx_display_Txt(&max72xx, str);
					ForceDisp = 0;    //Force diplay is one time deal
					}
				break;

			case 7:				//Right reel diameter
				//if((vDispNewDataFlgs & DispRRD) || (ForceDisp == 1))
				if((vDispNewDataFlgs & Disp_CNT) || (ForceDisp == 1))
					{
					sprintf(str,"DR%.2f", DReel_Cur_R);
					max72xx_display_Txt(&max72xx, str);
					ForceDisp = 0;    //Force display is one time deal
					}
				break;

			case 8:				//Display brightness
				if (ForceDisp == 1)
					{
					max72xx_display_Txt(&max72xx, "SET D.");
					ForceDisp = 0;    //Force display is one time deal
					}
				break;

			case 81:				//Display brightness
				if (ForceDisp == 1)
					{
					sprintf(str,"BRT%02d", vDispBRT);
					max72xx_display_Txt(&max72xx, str);
					ForceDisp = 0;    //Force display is one time deal
					}
				break;

			case 82:				//Display brightness
				if (ForceDisp == 1)
					{
					if(vDefDisp == 1)
						max72xx_display_Txt(&max72xx, "L-TP. ");
					else if(vDefDisp == 2)
						max72xx_display_Txt(&max72xx, "T-TP. ");
					else
						max72xx_display_Txt(&max72xx, "CNT.  ");

					ForceDisp = 0;    //Force display is one time deal
					}
				break;
			}

		vDispNewDataFlgs = 0; //reset the new data Flag
		}

}

