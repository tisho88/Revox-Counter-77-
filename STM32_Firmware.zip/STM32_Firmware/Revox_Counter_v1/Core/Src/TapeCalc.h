/*
 * TapeCalc.h
 *
 *  Created on: Sep 29, 2024
 *      Author: Tisho
 */

#ifndef SRC_TAPECALC_H_
#define SRC_TAPECALC_H_

void UpdReelData();

#endif /* SRC_TAPECALC_H_ */
