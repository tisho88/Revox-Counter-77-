/*
 * TapeCalc.c
 *
 *  Created on: Sep 29, 2024
 *      Author: Tisho
 */

#include "TapeCalc.h"
#include "globals.h"
#include "sys_stm32f401.h"
#include <math.h>

//********************* Update the data from the Reels *******************************
//All tape calculations done here
void UpdReelData(){

static float D_RR=0, D_LR=0;
static float Old_D_RR, Old_D_LR;  //Old Diameter Left and Right reel (from previous meserment)
static float TapeThR = DefTypTapeThick, TapeThL = DefTypTapeThick;    //Tape thikness calculated from the right and left reel
float TapeThR_Cur, TapeThL_Cur;   //the fresh calculated tape thiknes (from the right reel)

long CntTmR_LReel;
static float Avg_CntTmR_LReel;

static float DReel_Cal_R;           //measured Diameter of the rell during calibration Right
static float DReel_Cal_L;           //measured Diameter of the rell during calibration Left

//static float DReel_Cur_R;           //calculated Diameter of the rell (every lenght calculation) Right - needed if we want to "0" the counter
//static float DReel_Cur_L;           //calculated Diameter of the rell (every lenght calculation) Left - needed if we want to "0" the counter

static float LTapeL;
static float LTapeR;

static char FlgPreCalReel;     //Flag indicating wich Reel is smaller in Pre-Calibration mode (few rotations done but not all DefCallDur)

static char TapeModeCount;     //Counter used to determine the Mode

float CurDtcTapeSpeed;            //Current detected tape speed
static float OldDtcTapeSpeed;            //Old detected tape speed
static char CntValTapeSpeed;   //Counter of a valid tape speed measuments


//Check the mode of the machine
  if(Verify100msFlg())
    {
      TapeModeCount++;
      if(TapeModeCount>100)   //the bigest reel makes aprox. for 0,89s makes 1/4 rotation
        {
          FlgTapeMode = 0;    //Stop
          TapeModeCount=100;  //do not increase
        }
      else if(FlgTapeMode == 0)
         FlgTapeMode = 5;     //Play/rewind - tape is moving (here not sure if it Play or RW/FF)
                              //Below is determined!
    }
 //********************* Counter Reset *************************
 //just "0" the counters but use the old calibration
  if(FlgCountRST)
    {
    FlgCountRST = 0;

    DReel_Cal_R = DReel_Cur_R;
    DReel_Cal_L = DReel_Cur_L;

    CntRR = 0;
    CntLR = 0;

    LTapeR = 0;
    LTapeL = 0;
    LTape = 0;

   // FlgLTapeUpd = 1;
   // FlgTapeCntUpd = 1;
    vDispNewDataFlgs |= Disp_LT;
    vDispNewDataFlgs |= Disp_CNT;
    ForceDisp = 1;        //Force diplay


//    Serial.println("Counter Reset!");
//    Serial.print("DReel_Cur_R:");
//    Serial.println(DReel_Cur_R);

//    Serial.print("DReel_Cur_L:");
//    Serial.println(DReel_Cur_L);
    }

  if(FlgNewDataRR > 0)            //is there a new detect on the right reel
    {
     TapeModeCount = 0;          //reset the Tape mode counter

     CntTmR_LReel = CntTmRR + CntTmLR; //used to determine the speed and the mode (play or FF/RW)
     if((CntTmR_LReel>190000)&& (FlgTapeDir))             //experimental value on a play 19cm/s with smallest reel shuldn't be smaller the value
        FlgTapeMode = 1;    //Play                        //and we are moving to the right
     else
        FlgTapeMode = 3;   //FF/RW

      //Serial.println(CntTmR_LReel);

      //Speed detect in "Play" mode
     //9.5cm/s or 19cm/s
     if(FlgTapeMode == 1)   //if in a play mode determine the speed
      {
        float Diff = CntTmR_LReel-Avg_CntTmR_LReel;
        if(fabs(Diff)>1000)
          Avg_CntTmR_LReel = CntTmR_LReel;
    //    else if (fabs(Diff)>600)
    //      Avg_CntTmR_LReel = Avg_CntTmR_LReel + (CntTmR_LReel-Avg_CntTmR_LReel)/4;
    //    else if (fabs(Diff)>100)
    //      Avg_CntTmR_LReel = Avg_CntTmR_LReel + (CntTmR_LReel-Avg_CntTmR_LReel)/8;
        else
          Avg_CntTmR_LReel = Avg_CntTmR_LReel + (CntTmR_LReel-Avg_CntTmR_LReel)/16;

        //Serial.println(Avg_CntTmR_LReel);

        //if((CntTmRR_Full + CntTmLR_Full)>102000)       //Maybe need to be fine tuned later ?
        if(Avg_CntTmR_LReel>300000)       //Maybe need to be fine tuned later ?
          {
          //Serial.print("Speed:");
          //Serial.println("9.5");
          CurDtcTapeSpeed=9.5;
          }
        else
          {
          //Serial.print("Speed:");
          //Serial.println("19");
          CurDtcTapeSpeed=19;
          }
//
        if (CurDtcTapeSpeed == OldDtcTapeSpeed)
          {
          if (CntValTapeSpeed > VallidTpS)
            TapeSpeed=CurDtcTapeSpeed;
          else
            CntValTapeSpeed++;
          }
        else
          CntValTapeSpeed = 0;

        OldDtcTapeSpeed = CurDtcTapeSpeed;

        }

    if(FlgTapeDir)
      CntRR++;
    else
      CntRR--;
    //FlgTapeCntUpd = 1;      //Tape counter was updated
    vDispNewDataFlgs |= Disp_CNT; //Tape counter was updated

    //***** Calculate the Lenght for the right reel *****
    if ((FlgCalcCoeff <= DefRellDCallRot))    //Reliable reel diameter data should be ready
      {
     // if(FlgTapeDir)
     //   CntRR++;
     // else
     //   CntRR--;
                                                                      //TapeThick is in "um" rest is in "cm"
      //LTapeR= 0.7854*(DReel_Cal_R+TapeThick*CntRR/40000)*CntRR;       //3.14*(DReel_Cal_R+TapeThick*CntRR/40000)*CntRR/4;
    	LTapeR= 0.3927*(DReel_Cal_R+TapeThick*CntRR/80000)*CntRR;       //3.14*(DReel_Cal_R+TapeThick*CntRR/80000)*CntRR/8;  (8 reflectors)
      DReel_Cur_R = DReel_Cal_R +TapeThick*CntRR/40000;       //Calculate the current reel diameter (we will need it if we want to only reset the counter )
                                                                      //calc the diameter thats why 20000 instead of 40000
      if(FlgCalcCoeff != 0)    //Calibration not finished
        {
        if(FlgPreCalReel == 1)    //Calibration not finished - Right reel was smaller during pre calibration
          LTape = LTapeR;
        }
      else                      //Calibration is finished
        LTape = (LTapeR+LTapeL)/2;

      //Serial.print("LTape:");
      //Serial.println(LTape);
      //FlgLTapeUpd = 1;          //LTape was updated
      vDispNewDataFlgs |= Disp_LT;  //LTape was updated
      }
      FlgNewDataRR = 0;
    }


  //******************************* Full rotation on the right reel ********************************
   if(FlgNewFullR_RR > 0)         //is full rotation done (4 detects)on the right reel
    {
     //Serial.print("RR_Full:");
     //Serial.println(CntTmRR_Full);

     //Do the calculations only in "Play" mode
     if((FlgCalcCoeff) && (FlgTapeMode == 1))
      {

       D_RR=(TapeSpeed*CntTmRR_Full*0.000002)/3.14;     //New diameter of the right reel calculated (2us timer tact - if changed have to update here as well)
       if((D_RR < ReelMax) && (D_RR > ReelMin))         //if in reasanoble range proceed wit the calculations
        {
        FlgCalcCoeff--;                                 //Reduce the calibration counter (flag)

        if(FlgCalcCoeff == DefRellDCallRot)     //is it reached the amount of rotations to have reliable Reel diameter
          {
          if (CntTmLR_Full > CntTmRR_Full)      //Which reel is smaller
            {                                   //
            FlgPreCalReel = 1;                  //set the flag that right reel will be used for pre-calibration
            DReel_Cal_R=D_RR;
            }
          else
            {
            FlgPreCalReel = 0;                  //set the flag that left reel will be used for pre-calibration
            DReel_Cal_L=D_LR;
            }

          //Got the initial data (min one of the reel diameters), for reliable tape thikness have to collect more
//          Serial.print("Reel DiameterR:");
//          Serial.println(DReel_Cal_R);
//          Serial.print("Reel DiameterL:");
//          Serial.println(DReel_Cal_L);
//          Serial.print("Tape Thikness:");
//          Serial.println(TapeThick);

          //Got the initial data (min one of the reel diameters), for reliable tape thikness have to collect more
          }

       TapeThR_Cur = (D_RR-Old_D_RR)*5000;    //D/2 in um
       if((TapeThR_Cur<0)||(TapeThR_Cur > DefMaxTapeThick))
          TapeThR_Cur = TapeThR;      //ignor the negative results

//       if((fabs(TapeThR - TapeThR_Cur)  > 100) || (TapeThR < 0))    //huge difference - no averaging
//        TapeThR = TapeThR_Cur;
//       else if (fabs(TapeThR - TapeThR_Cur)  > 10)
//        TapeThR = TapeThR + (TapeThR_Cur-TapeThR)/2;        //tape thicness in cm with averaging
//       else if (fabs(TapeThR - TapeThR_Cur)  > 5)
//        TapeThR = TapeThR + (TapeThR_Cur-TapeThR)/4;        //tape thicness in cm with averaging
//       else
        TapeThR = TapeThR + (TapeThR_Cur-TapeThR)/16;        //tape thicness in cm with averaging

       TapeThick=(TapeThR+TapeThL)/2;         //

       if(FlgCalcCoeff == 1)    //The thickness calibration on the end
        {                       //Take both reel diameters at the moment
        DReel_Cal_R = D_RR;
        DReel_Cal_L = D_LR;
//        Serial.print("Tape Thikness:");
//        Serial.println(TapeThick);
        }

 //      Serial.print("TapeThick:");
 //      Serial.println(TapeThick);    //
 //     Serial.print("RR_Full:");
 //     Serial.println(CntTmRR_Full);

        Old_D_RR=D_RR;

      }
     }
     FlgNewFullR_RR = 0;
    }




  if(FlgNewDataLR > 0)                  //is there a new detect on the left reel
    {
    TapeModeCount = 0;                  //reset the Tape mode counter
    //Serial.print("CntTmLR:");
    //Serial.println(CntTmLR);

    if(FlgTapeDir)
      CntLR--;
    else
      CntLR++;

    //FlgTapeCntUpd = 1;    //Tape counter was updated
    vDispNewDataFlgs |= Disp_CNT; //Tape counter was updated

    //***** Calculate the Lenght for the Left reel *****
    if (FlgCalcCoeff <= DefRellDCallRot)    //Reliable reel diameter data shuld be ready
        {                                      //for short after "reset" time Default tape thiknes is used
 //        if(FlgTapeDir)
 //           CntLR--;
 //        else
 //           CntLR++;

         LTapeL= -0.3927*(DReel_Cal_L+TapeThick*CntLR/80000)*CntLR;  //-3.14*(DReel_Cal_L+TapeThick*CntLR/80000)*CntLR/8;		//check the right reel calc
         DReel_Cur_L = DReel_Cal_L +TapeThick*CntLR/40000;       //Calculate the current reel diameter (we will need it if we want to only reset the counter )


         if(FlgCalcCoeff != 0)    //Calibration not finished
            {
            if(FlgPreCalReel == 0)    //Calibration not finished - left reel was smaller during pre calibration
              LTape = LTapeL;
            }
          else
            LTape = (LTapeR+LTapeL)/2;



          //Serial.print("LTape:");
          //Serial.println(LTape);
         // FlgLTapeUpd = 1;          //LTape was updated
          vDispNewDataFlgs |= Disp_LT;  //LTape was updated
        }


    FlgNewDataLR = 0;
    }

  //******************************* Full rotation on the left reel ********************************
  if(FlgNewFullR_LR > 0)                //is full rotation done (4 detects)on the left reel
      {
      //Do the calculations only in "Play" mode
      if((FlgCalcCoeff)&& (FlgTapeMode == 1))
        {
        D_LR=(TapeSpeed*CntTmLR_Full*0.000002)/3.14;		//New diameter of the right reel calculated (2us timer tact - if changed have to update here as well)
        if((D_LR < ReelMax) && (D_LR > ReelMin))
        {
         //Serial.print("D_LR:");
         //Serial.println(D_LR);

          FlgCalcCoeff--;

          if(FlgCalcCoeff == DefRellDCallRot)     //is it reached the anount of rotations for reliable Reel diameter readout
          {
          if (CntTmLR_Full > CntTmRR_Full)
            {
            FlgPreCalReel = 1;                    //Right reel is smaller
            DReel_Cal_R=D_RR;
            }
          else
            {
            FlgPreCalReel = 0;
            DReel_Cal_L=D_LR;
            }

//          Serial.print("Reel DiameterR:");
//          Serial.println(DReel_Cal_R);
//          Serial.print("Reel DiameterL:");
//          Serial.println(DReel_Cal_L);
//          Serial.print("Tape Thikness:");
//          Serial.println(TapeThick);
           }

          TapeThL_Cur = (Old_D_LR-D_LR)*5000;    //D/2 in um
          if((TapeThL_Cur<0)||(TapeThL_Cur > DefMaxTapeThick))
            TapeThL_Cur = TapeThL;      //ignor the negative results

//      if((fabs(TapeThL - TapeThL_Cur)  > 100) || (TapeThL < 0))    //huge difference - no averaging
//       TapeThL = TapeThL_Cur;
//      else if (fabs(TapeThL - TapeThL_Cur)  > 20)
//       TapeThL = TapeThL + (TapeThL_Cur-TapeThL)/2;        //tape thicness in cm with averaging
//      else if (fabs(TapeThL - TapeThL_Cur)  > 10)
//       TapeThL = TapeThL + (TapeThL_Cur-TapeThL)/4;        //tape thicness in cm with averaging
//      else
       TapeThL = TapeThL + (TapeThL_Cur-TapeThL)/16;        //tape thicness in cm with averaging

      TapeThick=(TapeThR+TapeThL)/2;

      if(FlgCalcCoeff == 1)    //The thikness calibration on the end
        {                       //Take both reel diameters at the moment
        DReel_Cal_R = D_RR;
        DReel_Cal_L = D_LR;
//        Serial.print("Tape Thikness:");
//        Serial.println(TapeThick);
        }

       Old_D_LR=D_LR;

         }
      }
     FlgNewFullR_LR = 0;
    }
}
