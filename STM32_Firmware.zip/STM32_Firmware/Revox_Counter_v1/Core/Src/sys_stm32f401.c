/*
 * sys_stm32f401.c
 *
 *  Created on: Sep 25, 2024
 *      Author: Tisho
 */

# include "sys_stm32f401.h"
# include "globals.h"
# include "main.h"

//----- global variables and constants -------------------------------------------
unsigned int vSysTm10ms, vSysTm100ms,vSysTm1s;

#define  IntSysTm1ms      1
#define  SysTm1ms         2
#define  SysTm10ms   	  4
#define  SysTm100ms       8
#define  SysTm1s		 16


//************* Scan  Timer0 status **********************************************
//  Soft timer flags support of 10 ms, 100ms, 1s time interval
//
#define M_TMSYS_FLG 0x1f  // Soft timer flag mask (fIntSysTm10ms | fSysTm10ms | fSysTm100ms | fSysTm1s)
void ScanTimer3(void)
{
 	if ((vSysFlgs & M_TMSYS_FLG) == IntSysTm1ms)                  // hardware flag
     {  vSysFlgs &= ~IntSysTm1ms;
	    vSysFlgs |= SysTm1ms;         // Soft timer flag
      } // -------------------      if (TIMER0_IR && 1)
    else if (vSysFlgs & SysTm1ms)
           {  ++vSysTm10ms;
	          if (vSysTm10ms==10)
                { vSysTm10ms=0;
               	 vSysFlgs|= SysTm10ms;   // set 10ms flag
                } // ------------------------
      	      vSysFlgs &= ~SysTm1ms;   // Soft timer flag
           }  // else if (vSysFlgs & fSysFlgsTm1ms)
       else if (vSysFlgs & SysTm10ms)
           {   ++vSysTm100ms;
    	      if (vSysTm100ms==10)
       		   { vSysTm100ms=0;
       	         vSysFlgs|= SysTm100ms;      // set 100ms  flag
                } //-------------------------
   	         vSysFlgs &= ~SysTm10ms;     // Soft timer flag
           }  // else if (vSysFlgs & fSysFlgsTm10ms)
   	      else if (vSysFlgs & SysTm100ms)
   	                 {   ++vSysTm1s;
   	          	      if (vSysTm1s==10)
   	             		   { vSysTm1s=0;
   	             	         vSysFlgs|= SysTm1s;      // set 1s  flag
   	                      } //-------------------------
   	         	         vSysFlgs &= ~SysTm100ms;     // Soft timer flag
   	                 } //------------------------------ else if (SysFlgs && fSysFlgsTm100ms)
          else if (vSysFlgs & SysTm1s)
            { vSysFlgs &= ~SysTm1s;  // Soft timer flag
            } //------------------------------- else if (SysFlgs && fSysFlgsTm1s)
} // end of ScanTimer0

//***********  Verify  1ms  Soft Timer Flag *******************************************
unsigned int Verify1msFlg(void)
{ return (vSysFlgs & SysTm1ms);
} // end of Verify1msFlg(void)

//***********  Verify  10ms  Soft Timer Flag *******************************************
unsigned int Verify10msFlg(void)
{ return (vSysFlgs & SysTm10ms);
} // end of Verify1msFlg(void)

//***********  Verify 100ms Soft Timer Flag ********************************************
unsigned int Verify100msFlg(void)
{ return (vSysFlgs & SysTm100ms);
} // end of Verify1msFlg(void)

//***********  Verify 1s Soft Timer Flag ***********************************************
unsigned int Verify1sFlg(void)
{ return (vSysFlgs & SysTm1s);
} // end of Verify1msFlg(void)

/* 0 - no press
 * 1 - short press
 * 2 - long press
 * 3 - double press
 *
 */
unsigned int ScanBTN(void)
{
	#define LongPress	30
	#define DoublePress	8				//400ms (8*50ms)


	static char TmCount;				//how often to check the button
	static unsigned int BtnActPressTm;
	static unsigned int BtnActReleaseTm;

	static char EventFired;

//	static char OldBTN_State;
//	char BTN_State=0;

	char Ret_State = 0;

	if (Verify10msFlg()) //test option
		{
		TmCount++;
		if(TmCount>=5)
			{
			TmCount=0;

			if(HAL_GPIO_ReadPin (USR_BTN_GPIO_Port, USR_BTN_Pin))		//button released
				{
			//	BTN_State = 0;

				if((BtnActPressTm > 0) && (BtnActReleaseTm > DoublePress)) //the button was pressed and after the releas not pressed again
					{
					if(EventFired == 0)
						Ret_State = 1;		//Short press

					else
						EventFired = 0;				//clear the flag for fired event

					BtnActPressTm = 0;
					}

				BtnActReleaseTm++;
				//EventFired = 0;				//clear the flag for fired event
				}
			else														//button pressed
				{
				//BTN_State = 1;

				if((BtnActReleaseTm < DoublePress) && (BtnActReleaseTm > 0))
					{
					Ret_State = 3;		//double press
					EventFired = 1;		//Event fired
					}

				BtnActPressTm++;
				BtnActReleaseTm = 0;
				}

			if((BtnActPressTm > LongPress) && (EventFired == 0))		//time reached and the event was not fired yet
				{
				Ret_State = 2;		//Long press
				EventFired = 1;		//Event fired
				}

			/*
			if ((BTN_State == 1) && (BTN_State != OldBTN_State))
				{
				OldBTN_State = BTN_State;
				return 1;
				}
			else
				{
				OldBTN_State = BTN_State;
				return 0;
				}
			*/
			}
		}
	return Ret_State;
}


