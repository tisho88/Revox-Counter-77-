/*
 * sys_stm32f401.h
 *
 *  Created on: Sep 25, 2024
 *      Author: Tisho
 */

#ifndef SRC_SYS_STM32F401_H_
#define SRC_SYS_STM32F401_H_

void ScanTimer3(void);
unsigned int Verify1msFlg(void);
unsigned int Verify10msFlg(void);
unsigned int Verify100msFlg(void);
unsigned int Verify1sFlg(void);

unsigned int ScanBTN(void);

#endif /* SRC_SYS_STM32F401_H_ */
